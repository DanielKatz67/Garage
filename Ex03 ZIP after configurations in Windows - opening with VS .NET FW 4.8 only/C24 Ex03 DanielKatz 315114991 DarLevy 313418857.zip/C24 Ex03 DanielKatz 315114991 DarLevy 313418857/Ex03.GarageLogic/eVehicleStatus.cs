namespace Ex03.GarageLogic
{
    public enum eVehicleStatus
    {
        InRepair = 1,
        RepairedAwaitingPayment = 2,
        RepairedAndPaid = 3,
    }
}

