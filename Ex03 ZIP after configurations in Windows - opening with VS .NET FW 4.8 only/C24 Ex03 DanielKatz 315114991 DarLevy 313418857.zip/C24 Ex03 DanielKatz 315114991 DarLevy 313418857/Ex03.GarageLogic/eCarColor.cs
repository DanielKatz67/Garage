namespace Ex03.GarageLogic
{
    public enum eCarColor
    {
            Blue = 1,
            White = 2,
            Black = 3,
            Red = 4,
    }
}