namespace Ex03.GarageLogic
{
    public enum eFuelType
    {
        Soler = 1,
        Octan95 = 2,
        Octan96 = 3,
        Octan98 = 4,
    }
}