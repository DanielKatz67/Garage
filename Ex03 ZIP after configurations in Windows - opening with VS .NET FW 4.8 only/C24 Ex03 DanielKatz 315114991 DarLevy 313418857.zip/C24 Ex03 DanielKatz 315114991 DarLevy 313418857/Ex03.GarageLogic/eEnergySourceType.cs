namespace Ex03.GarageLogic
{
    public enum eEnergySourceType
    {
        Fuel = 1,
        Electric = 2,
    }
}