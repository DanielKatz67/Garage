namespace Ex03.GarageLogic
{
    public enum eMotorcycleLicenseType
    {
        A1 = 1,
        A2 = 2,
        AB = 3,
        B1 = 4,
    }
}