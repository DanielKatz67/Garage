namespace Ex03.GarageLogic
{
    public enum eVehicleType
    {
        Motorcycle = 1,
        Car = 2,
        Truck = 3,
    }
}

