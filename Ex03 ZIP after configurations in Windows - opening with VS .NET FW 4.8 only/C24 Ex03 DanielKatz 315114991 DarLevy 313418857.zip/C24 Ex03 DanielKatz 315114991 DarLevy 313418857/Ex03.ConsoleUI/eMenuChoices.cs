namespace Ex03.ConsoleUI
{
    public enum eMenuChoices
    {
        InsertVehicle = 1,
        ShowLicensePlates = 2,
        ChangeVehicleStatus = 3,
        InflateWheelsToMax = 4,
        Refuel = 5,
        Charge = 6,
        ShowVehicleFullDetails = 7,
        Exit = 8
    }
}

