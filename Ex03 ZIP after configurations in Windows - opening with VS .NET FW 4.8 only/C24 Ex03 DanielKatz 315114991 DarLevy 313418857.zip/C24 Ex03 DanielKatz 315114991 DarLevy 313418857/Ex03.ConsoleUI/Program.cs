﻿
namespace Ex03.ConsoleUI
{
    public class Program
    {
        public static void Main()
        {
            GarageUI garage = new GarageUI();
            garage.Run();
        }
    }
}

